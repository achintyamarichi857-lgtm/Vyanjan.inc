import 'react-native-url-polyfill/auto';
import React, { useEffect, useState } from 'react';
import {
  Alert, ActivityIndicator, Button, FlatList, Image, SafeAreaView,
  ScrollView, Text, TextInput, TouchableOpacity, View
} from 'react-native';
import * as Location from 'expo-location';
import * as ImagePicker from 'expo-image-picker';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { StatusBar } from 'expo-status-bar';
import { createClient, Session } from '@supabase/supabase-js';

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL || '';
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || '';
const supabase = createClient(supabaseUrl || 'https://example.supabase.co', supabaseKey || 'demo-key', {
  auth: { storage: AsyncStorage, autoRefreshToken: true, persistSession: true, detectSessionInUrl: false }
});
const green = '#14583D';
const pale = '#EEF6F0';
type Profile = { id: string; full_name: string | null; role: 'owner'|'staff'|'customer' };
type Row = Record<string, any>;

function Btn({ title, onPress, secondary=false }: {title:string; onPress:()=>void; secondary?:boolean}) {
  return <TouchableOpacity onPress={onPress} style={{backgroundColor: secondary ? '#E5EEE8' : green, padding:13, borderRadius:10, marginVertical:5}}>
    <Text style={{color:secondary?green:'#fff',fontWeight:'700',textAlign:'center'}}>{title}</Text>
  </TouchableOpacity>;
}
function Field(props:any) {
  return <TextInput placeholderTextColor="#78847D" {...props} style={[{borderWidth:1,borderColor:'#D6E0D9',borderRadius:10,padding:12,marginVertical:5,backgroundColor:'#fff',color:'#17251D'},props.style]} />;
}
function Card({children}:any) {
  return <View style={{backgroundColor:'#fff',padding:14,borderRadius:14,marginVertical:6,borderWidth:1,borderColor:'#E0E9E2'}}>{children}</View>;
}

export default function App() {
  const [session, setSession] = useState<Session|null>(null);
  const [profile, setProfile] = useState<Profile|null>(null);
  const [loading, setLoading] = useState(true);
  const [screen, setScreen] = useState('Home');
  const [email,setEmail] = useState('');
  const [password,setPassword] = useState('');
  const [name,setName] = useState('');
  const [rows,setRows] = useState<Row[]>([]);
  const [customers,setCustomers] = useState<Row[]>([]);
  const [menu,setMenu] = useState<Row[]>([]);
  const [customerName,setCustomerName] = useState('');
  const [customerPhone,setCustomerPhone] = useState('');
  const [foodName,setFoodName] = useState('');
  const [foodPrice,setFoodPrice] = useState('');
  const [billCustomer,setBillCustomer] = useState('');
  const [billAmount,setBillAmount] = useState('');
  const [dueDate,setDueDate] = useState('');
  const [paymentBill,setPaymentBill] = useState('');
  const [paymentAmount,setPaymentAmount] = useState('');
  const [deliveryOrder,setDeliveryOrder] = useState('');
  const [address,setAddress] = useState('');
  const [latitude,setLatitude] = useState<number|null>(null);
  const [longitude,setLongitude] = useState<number|null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({data}) => { setSession(data.session); setLoading(false); });
    const {data:{subscription}} = supabase.auth.onAuthStateChange((_event,s) => setSession(s));
    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => { if(session) loadProfile(); else {setProfile(null);setRows([]);} }, [session]);

  async function loadProfile() {
    const {data,error} = await supabase.from('profiles').select('*').eq('id',session!.user.id).single();
    if(error) { Alert.alert('Profile not ready','Ask the app owner to configure your role in Supabase.'); return; }
    setProfile(data as Profile);
    await refreshData(data.role);
  }
  async function refreshData(role=profile?.role) {
    if(!role) return;
    const tasks = await Promise.all([
      supabase.from('orders').select('*, customers(full_name), profiles:delivery_staff_id(full_name)').order('created_at',{ascending:false}),
      supabase.from('customers').select('*').order('full_name'),
      supabase.from('menu_items').select('*').eq('is_available',true).order('name')
    ]);
    if(!tasks[0].error) setRows(tasks[0].data||[]);
    if(!tasks[1].error) setCustomers(tasks[1].data||[]);
    if(!tasks[2].error) setMenu(tasks[2].data||[]);
  }
  async function signIn() {
    if(!supabaseUrl || !supabaseKey) { Alert.alert('Setup required','Add your Supabase URL and anon key to .env first. See README.md.'); return; }
    const {error}=await supabase.auth.signInWithPassword({email:email.trim(),password});
    if(error) Alert.alert('Login failed',error.message);
  }
  async function signUp() {
    if(!name.trim() || !email.trim() || password.length<8) {Alert.alert('Check details','Enter your name, email, and a password with at least 8 characters.');return;}
    const {error}=await supabase.auth.signUp({email:email.trim(),password,options:{data:{full_name:name.trim()}}});
    if(error) Alert.alert('Sign-up failed',error.message);
    else Alert.alert('Account created','Check your email if confirmation is enabled. Ask the owner to assign your role if needed.');
  }
  async function addCustomer() {
    if(!customerName.trim()) return Alert.alert('Required','Enter a customer name.');
    const {error}=await supabase.from('customers').insert({full_name:customerName.trim(),phone:customerPhone.trim()||null,address:address.trim()||null,latitude,longitude});
    if(error) Alert.alert('Could not add customer',error.message);
    else {setCustomerName('');setCustomerPhone('');setAddress('');setLatitude(null);setLongitude(null);await refreshData();Alert.alert('Saved','Customer added.');}
  }
  async function shareLocation() {
    const {status}=await Location.requestForegroundPermissionsAsync();
    if(status!=='granted') return Alert.alert('Location permission','You can enter the delivery address manually or allow location access in settings.');
    const loc=await Location.getCurrentPositionAsync({});
    setLatitude(loc.coords.latitude);setLongitude(loc.coords.longitude);
    try {
      const result=await Location.reverseGeocodeAsync(loc.coords);
      if(result[0]) setAddress([result[0].name,result[0].street,result[0].city,result[0].region].filter(Boolean).join(', '));
    } catch {}
    Alert.alert('Location captured','Review the address before saving.');
  }
  async function addMenuItem() {
    if(!foodName.trim() || !Number.isFinite(Number(foodPrice)) || Number(foodPrice)<0) return Alert.alert('Check details','Enter a food name and valid price.');
    const {error}=await supabase.from('menu_items').insert({name:foodName.trim(),price:Number(foodPrice),is_available:true});
    if(error) Alert.alert('Could not add item',error.message);
    else {setFoodName('');setFoodPrice('');await refreshData();Alert.alert('Saved','Menu item added.');}
  }
  async function uploadMenuPhoto(item:Row) {
    const pick=await ImagePicker.launchImageLibraryAsync({mediaTypes:['images'],quality:0.8});
    if(pick.canceled) return;
    const asset=pick.assets[0];
    const response=await fetch(asset.uri);
    const blob=await response.blob();
    const path=`${item.id}/${Date.now()}.jpg`;
    const {error:uploadError}=await supabase.storage.from('menu-photos').upload(path,blob,{contentType:'image/jpeg',upsert:true});
    if(uploadError) return Alert.alert('Upload failed',uploadError.message);
    const {data}=supabase.storage.from('menu-photos').getPublicUrl(path);
    const {error}=await supabase.from('menu_items').update({photo_url:data.publicUrl}).eq('id',item.id);
    if(error) Alert.alert('Photo saved but menu update failed',error.message);
    else {await refreshData();Alert.alert('Uploaded','Menu photo uploaded.');}
  }
  async function createOrder() {
    if(!billCustomer || !Number(billAmount) || Number(billAmount)<=0) return Alert.alert('Check details','Choose a customer ID and enter a valid amount.');
    const {error}=await supabase.from('orders').insert({customer_id:billCustomer,created_by:session!.user.id,total_amount:Number(billAmount),due_date:dueDate||null,status:'pending',delivery_address:address||null});
    if(error) Alert.alert('Could not create order',error.message);
    else {setBillAmount('');await refreshData();Alert.alert('Order created','Order and bill created.');}
  }
  async function recordPayment() {
    const amt=Number(paymentAmount);
    if(!paymentBill || !Number.isFinite(amt) || amt<=0) return Alert.alert('Check details','Enter an order ID and payment amount.');
    const {error}=await supabase.from('payments').insert({order_id:paymentBill,amount:amt,recorded_by:session!.user.id,method:'cash'});
    if(error) Alert.alert('Payment failed',error.message);
    else {setPaymentAmount('');setPaymentBill('');await refreshData();Alert.alert('Recorded','Payment recorded.');}
  }
  async function updateDelivery() {
    if(!deliveryOrder) return Alert.alert('Required','Enter an order ID.');
    const {error}=await supabase.from('orders').update({status:'delivered',delivered_at:new Date().toISOString()}).eq('id',deliveryOrder);
    if(error) Alert.alert('Could not update',error.message);
    else {await refreshData();Alert.alert('Updated','Order marked delivered.');}
  }

  if(loading) return <SafeAreaView style={{flex:1,justifyContent:'center'}}><ActivityIndicator size="large" color={green}/></SafeAreaView>;
  if(!session) return <SafeAreaView style={{flex:1,backgroundColor:pale,padding:22,justifyContent:'center'}}>
    <StatusBar style="dark"/>
    <Text style={{fontSize:34,fontWeight:'900',color:green}}>Nutry Vyanjan</Text>
    <Text style={{fontSize:16,color:'#52675A',marginBottom:20}}>Food Supply • Orders • Deliveries</Text>
    <Card><Text style={{fontSize:20,fontWeight:'800',color:green}}>Login or create account</Text>
      <Field value={name} onChangeText={setName} placeholder="Full name (for sign up)"/>
      <Field value={email} onChangeText={setEmail} placeholder="Email" autoCapitalize="none" keyboardType="email-address"/>
      <Field value={password} onChangeText={setPassword} placeholder="Password (min. 8 characters)" secureTextEntry/>
      <Btn title="Log in" onPress={signIn}/>
      <Btn title="Create account" secondary onPress={signUp}/>
      <Text style={{fontSize:12,color:'#617268',marginTop:8}}>New accounts are customers by default. The owner assigns staff/owner roles securely in Supabase.</Text>
    </Card>
  </SafeAreaView>;

  if(!profile) return <SafeAreaView style={{flex:1,justifyContent:'center',padding:24}}><ActivityIndicator color={green}/><Text style={{textAlign:'center',margin:12}}>Loading your profile…</Text><Btn title="Sign out" onPress={()=>supabase.auth.signOut()}/></SafeAreaView>;

  const isManager=profile.role==='owner'||profile.role==='staff';
  const money=(n:number)=>'₹'+Number(n||0).toLocaleString('en-IN');
  const nav = profile.role==='owner'
    ? ['Home','Customers','Menu','Orders','Payments','Reports']
    : profile.role==='staff'
    ? ['Home','Customers','Menu','Orders','Payments','Deliveries']
    : ['Home','Menu','My Orders','My Bills','Profile'];

  return <SafeAreaView style={{flex:1,backgroundColor:pale}}>
    <StatusBar style="light"/>
    <View style={{backgroundColor:green,padding:18}}>
      <Text style={{color:'#DDEFE4',fontSize:12}}>FOOD SUPPLY MANAGEMENT</Text>
      <Text style={{color:'#fff',fontSize:25,fontWeight:'900'}}>Nutry Vyanjan</Text>
      <Text style={{color:'#DDEFE4'}}>Hello, {profile.full_name||'there'} · {profile.role.toUpperCase()}</Text>
    </View>
    <ScrollView contentContainerStyle={{padding:14,paddingBottom:30}}>
      {screen==='Home' && <>
        <Text style={{fontSize:22,fontWeight:'800',color:green,marginBottom:10}}>{profile.role==='customer'?'Your food & orders':'Business dashboard'}</Text>
        <View style={{flexDirection:'row',flexWrap:'wrap'}}>
          {[
            ['Orders',String(rows.length)],['Customers',String(customers.length)],
            ['Outstanding',money(rows.reduce((s,r)=>s+Math.max(0,Number(r.total_amount||0)-Number(r.paid_amount||0)),0))],
            ['Deliveries',String(rows.filter(r=>['out_for_delivery','preparing'].includes(r.status)).length)]
          ].slice(0,isManager?4:2).map(([label,value])=><View key={label} style={{width:'48%',margin:'1%',backgroundColor:'#fff',padding:15,borderRadius:12}}><Text style={{color:'#64756A'}}>{label}</Text><Text style={{fontSize:21,fontWeight:'800',color:green}}>{value}</Text></View>)}
        </View>
        <Text style={{fontSize:18,fontWeight:'800',marginTop:18,marginBottom:5}}>Quick actions</Text>
        {nav.filter(n=>n!=='Home').map(n=><Btn key={n} title={n} secondary onPress={()=>setScreen(n)}/>)}
        <Btn title="Refresh data" onPress={()=>refreshData()}/>
        <Btn title="Log out" secondary onPress={()=>supabase.auth.signOut()}/>
      </>}
      {screen==='Customers' && isManager && <>
        <Text style={{fontSize:22,fontWeight:'800',color:green}}>Customers</Text>
        <Field value={customerName} onChangeText={setCustomerName} placeholder="Customer full name"/>
        <Field value={customerPhone} onChangeText={setCustomerPhone} placeholder="Phone number" keyboardType="phone-pad"/>
        <Field value={address} onChangeText={setAddress} placeholder="Delivery address"/>
        <Btn title="Use my current location" secondary onPress={shareLocation}/>
        {latitude!==null && <Text style={{color:green}}>Location ready: {latitude.toFixed(5)}, {longitude?.toFixed(5)}</Text>}
        <Btn title="Save customer" onPress={addCustomer}/>
        {customers.map(c=><Card key={c.id}><Text style={{fontWeight:'800'}}>{c.full_name}</Text><Text>{c.phone||'No phone'}</Text><Text>{c.address||'No address'}</Text></Card>)}
      </>}
      {screen==='Menu' && <>
        <Text style={{fontSize:22,fontWeight:'800',color:green}}>Food menu</Text>
        {isManager && <><Field value={foodName} onChangeText={setFoodName} placeholder="Food name"/><Field value={foodPrice} onChangeText={setFoodPrice} placeholder="Price in ₹" keyboardType="decimal-pad"/><Btn title="Add menu item" onPress={addMenuItem}/></>}
        {menu.map(m=><Card key={m.id}>
          {m.photo_url ? <Image source={{uri:m.photo_url}} style={{height:150,borderRadius:10,marginBottom:8}}/>:null}
          <Text style={{fontWeight:'800',fontSize:17}}>{m.name}</Text><Text>{money(m.price)}</Text>
          {isManager && <Btn title="Upload food photo" secondary onPress={()=>uploadMenuPhoto(m)}/>}
        </Card>)}
      </>}
      {(screen==='Orders'||screen==='My Orders'||screen==='My Bills') && <>
        <Text style={{fontSize:22,fontWeight:'800',color:green}}>{screen}</Text>
        {isManager && <>
          <Text style={{fontWeight:'700',marginTop:10}}>Create order / bill</Text>
          <Field value={billCustomer} onChangeText={setBillCustomer} placeholder="Customer UUID (from database)" autoCapitalize="none"/>
          <Field value={billAmount} onChangeText={setBillAmount} placeholder="Total amount ₹" keyboardType="decimal-pad"/>
          <Field value={dueDate} onChangeText={setDueDate} placeholder="Due date YYYY-MM-DD"/>
          <Field value={address} onChangeText={setAddress} placeholder="Delivery address (optional)"/>
          <Btn title="Create order" onPress={createOrder}/>
        </>}
        {rows.map(r=><Card key={r.id}><Text style={{fontWeight:'800'}}>Order #{String(r.id).slice(0,8)}</Text><Text>Amount: {money(r.total_amount)} · Paid: {money(r.paid_amount)}</Text><Text>Due: {r.due_date||'Not set'} · Status: {r.status}</Text><Text>{r.delivery_address||'No delivery address'}</Text></Card>)}
      </>}
      {screen==='Payments' && isManager && <>
        <Text style={{fontSize:22,fontWeight:'800',color:green}}>Record payment</Text>
        <Field value={paymentBill} onChangeText={setPaymentBill} placeholder="Order UUID" autoCapitalize="none"/>
        <Field value={paymentAmount} onChangeText={setPaymentAmount} placeholder="Amount received ₹" keyboardType="decimal-pad"/>
        <Btn title="Record cash payment" onPress={recordPayment}/>
        <Text style={{color:'#617268',marginTop:8}}>Use the order UUID from your database. Payment totals and balances are stored separately.</Text>
      </>}
      {screen==='Deliveries' && isManager && <>
        <Text style={{fontSize:22,fontWeight:'800',color:green}}>Delivery desk</Text>
        {rows.map(r=><Card key={r.id}><Text style={{fontWeight:'800'}}>Order #{String(r.id).slice(0,8)}</Text><Text>{r.delivery_address||'Address not set'}</Text><Text>Status: {r.status}</Text></Card>)}
        <Field value={deliveryOrder} onChangeText={setDeliveryOrder} placeholder="Order UUID to mark delivered" autoCapitalize="none"/>
        <Btn title="Mark delivered" onPress={updateDelivery}/>
      </>}
      {screen==='Reports' && profile.role==='owner' && <>
        <Text style={{fontSize:22,fontWeight:'800',color:green}}>Reports</Text>
        <Card><Text>Total orders: {rows.length}</Text><Text>Total billed: {money(rows.reduce((s,r)=>s+Number(r.total_amount||0),0))}</Text><Text>Recorded paid amount: {money(rows.reduce((s,r)=>s+Number(r.paid_amount||0),0))}</Text><Text>Outstanding: {money(rows.reduce((s,r)=>s+Math.max(0,Number(r.total_amount||0)-Number(r.paid_amount||0)),0))}</Text><Text>Delivered: {rows.filter(r=>r.status==='delivered').length}</Text><Text>Overdue: {rows.filter(r=>r.due_date && r.due_date<new Date().toISOString().slice(0,10) && Number(r.paid_amount||0)<Number(r.total_amount||0)).length}</Text></Card>
      </>}
      {screen==='Profile' && <>
        <Text style={{fontSize:22,fontWeight:'800',color:green}}>Your profile</Text>
        <Card><Text>{profile.full_name}</Text><Text>{session.user.email}</Text><Text>Role: {profile.role}</Text><Text>Saved delivery address: {address||'Add an address during checkout or customer setup.'}</Text></Card>
        <Btn title="Share current location" onPress={shareLocation}/>
        <Btn title="Log out" secondary onPress={()=>supabase.auth.signOut()}/>
      </>}
    </ScrollView>
    <View style={{flexDirection:'row',backgroundColor:'#fff',borderTopWidth:1,borderColor:'#DCE6DF',paddingVertical:8,justifyContent:'space-around'}}>
      {nav.slice(0,5).map(n=><TouchableOpacity key={n} onPress={()=>setScreen(n)} style={{padding:5}}><Text style={{fontSize:11,fontWeight:screen===n?'800':'500',color:screen===n?green:'#65766A'}}>{n}</Text></TouchableOpacity>)}
    </View>
  </SafeAreaView>;
}
