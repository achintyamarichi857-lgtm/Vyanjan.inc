-- Nutry Vyanjan initial schema for Supabase.
-- Review and test all policies before production use.

create extension if not exists pgcrypto;

create type public.app_role as enum ('owner', 'staff', 'customer');
create type public.order_status as enum ('pending', 'preparing', 'out_for_delivery', 'delivered', 'cancelled');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role public.app_role not null default 'customer',
  created_at timestamptz not null default now()
);

create table public.customers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  full_name text not null,
  phone text,
  address text,
  latitude double precision,
  longitude double precision,
  created_at timestamptz not null default now()
);

create table public.menu_items (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  price numeric(12,2) not null default 0 check (price >= 0),
  photo_url text,
  is_available boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.customers(id),
  created_by uuid references public.profiles(id),
  delivery_staff_id uuid references public.profiles(id),
  total_amount numeric(12,2) not null check (total_amount >= 0),
  paid_amount numeric(12,2) not null default 0 check (paid_amount >= 0),
  due_date date,
  status public.order_status not null default 'pending',
  delivery_address text,
  delivery_latitude double precision,
  delivery_longitude double precision,
  created_at timestamptz not null default now(),
  delivered_at timestamptz,
  check (paid_amount <= total_amount)
);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  amount numeric(12,2) not null check (amount > 0),
  method text not null default 'cash',
  recorded_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create index customers_user_id_idx on public.customers(user_id);
create index orders_customer_id_idx on public.orders(customer_id);
create index orders_due_date_idx on public.orders(due_date);
create index orders_delivery_staff_id_idx on public.orders(delivery_staff_id);
create index payments_order_id_idx on public.payments(order_id);

create or replace function public.current_role()
returns public.app_role
language sql stable security definer
set search_path = public
as $$
  select role from public.profiles where id = auth.uid()
$$;

create or replace function public.handle_new_user()
returns trigger
language plpgsql security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name','New user'), 'customer')
  on conflict (id) do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.customers enable row level security;
alter table public.menu_items enable row level security;
alter table public.orders enable row level security;
alter table public.payments enable row level security;

create policy "Profiles self or owner/staff read" on public.profiles for select to authenticated
using (id = auth.uid() or public.current_role() in ('owner','staff'));
create policy "Users update own profile name" on public.profiles for update to authenticated
using (id = auth.uid()) with check (id = auth.uid());

create policy "Owner staff manage customers" on public.customers for all to authenticated
using (public.current_role() in ('owner','staff'))
with check (public.current_role() in ('owner','staff'));
create policy "Customer read own customer record" on public.customers for select to authenticated
using (user_id = auth.uid());

create policy "Authenticated read published menu" on public.menu_items for select to authenticated
using (is_available = true or public.current_role() in ('owner','staff'));
create policy "Owner staff insert menu" on public.menu_items for insert to authenticated
with check (public.current_role() in ('owner','staff'));
create policy "Owner staff update menu" on public.menu_items for update to authenticated
using (public.current_role() in ('owner','staff'))
with check (public.current_role() in ('owner','staff'));
create policy "Owner staff delete menu" on public.menu_items for delete to authenticated
using (public.current_role() in ('owner','staff'));

create policy "Owner staff read all orders, customers read own, assigned staff read" on public.orders for select to authenticated
using (
  public.current_role() in ('owner','staff')
  or exists (select 1 from public.customers c where c.id = customer_id and c.user_id = auth.uid())
);
create policy "Owner staff create orders" on public.orders for insert to authenticated
with check (public.current_role() in ('owner','staff'));
create policy "Owner staff update orders" on public.orders for update to authenticated
using (public.current_role() in ('owner','staff'))
with check (public.current_role() in ('owner','staff'));

create policy "Owner staff read payments" on public.payments for select to authenticated
using (public.current_role() in ('owner','staff') or exists (
  select 1 from public.orders o join public.customers c on c.id=o.customer_id
  where o.id=order_id and c.user_id=auth.uid()
));
create policy "Owner staff record payments" on public.payments for insert to authenticated
with check (public.current_role() in ('owner','staff'));

-- Payment records are append-only through the app; do not allow clients to edit/delete them.
-- For production, use a database trigger or secure RPC to update paid_amount atomically
-- and prevent overpayment/race conditions. Never trust client-supplied paid_amount.
