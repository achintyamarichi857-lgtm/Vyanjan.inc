# Nutry Vyanjan — Android starter app

An Expo React Native + Supabase starter for a food-supply business. It includes:
- Owner, staff, and customer role-aware navigation
- Customer records
- Orders and delivery status tracking
- Bill/payment tracking with partial payments
- Menu items and image upload to Supabase Storage
- Optional customer location permission and saved coordinates
- Reports overview

## Important
This is a starter project, not a published or production-ready app. You must configure a Supabase project, set environment variables, apply the SQL schema, and test permissions before using real customer data. Do not use demo credentials or expose a Supabase service-role key in the app.

## Setup
1. Install Node.js LTS and Git on a computer.
2. Install Expo Go on an Android phone.
3. Create a Supabase project at https://supabase.com.
4. In Supabase SQL Editor, run `supabase/schema.sql`.
5. Create a public bucket named `menu-photos` in Storage (or make it private and implement signed URLs before production).
6. Copy `.env.example` to `.env` and set your Supabase URL and anon key.
7. Run:
   ```bash
   npm install
   npx expo start
   ```
8. Scan the QR code with Expo Go.

## Create the first owner
For safety, sign up a user through the app or Supabase Auth, then set that user's role to `owner` in the Supabase SQL editor:
```sql
update public.profiles set role = 'owner' where id = 'AUTH_USER_UUID';
```
Only do this for the intended owner account.

## Notes
- Location is requested only after the user taps the location button. It is not continuously tracked.
- Customers should only be able to view their own records. The included RLS policies are a baseline and should be reviewed before real deployment.
- Payment records in this starter are manually recorded; no payment gateway is integrated.
- Real-time background tracking, maps routing, push notifications, GST invoices, and Play Store publishing are not included yet.
